r= float(input("Enter radious: "))
print(f"Area of the circle is: {3.1416*r**2}")
print(f"Perimeter of the circke is: {2*3.1416*r}")