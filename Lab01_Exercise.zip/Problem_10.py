list=[4,3,7,10,12]
sorted(list)
n=len(list)
print("Second largest number: ",list[n-2])