string = (input("Enter the string: "))
for i in range(0, len(string)):
    if(i%2==0):
        print(string[i])
