list=[1,2,3,4,5]
total= 0
for i in range(0,len(list)):
    total=total+list[i]
print("Sum is:",total)