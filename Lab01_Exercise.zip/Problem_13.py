string= 'CSE303'
count = 0
for i in string:
    count= count+1
print(count)
