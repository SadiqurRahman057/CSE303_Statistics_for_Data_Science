a = int(input("Enter first number: "))
b = int(input("Enter second number: "))
total= a+b
multiplication= a*b
if multiplication>1000:
    print(f"Sum of two number is: {total}")
else:
    print(f"Multiplication of two number is: {multiplication}")
