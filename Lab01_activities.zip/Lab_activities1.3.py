# conditional statements:
# if statement
x=4
if x<1:
    score= "low"
elif x<=4:
    score ="Medium"
else: 
    score= "High"
print(score)

# if statement with a boolean:
x= True
if x:
    print("it worked")
