# loops
veggies = ["Beans","Broc","Ban"]
for veggie in veggies:
    print(veggie)

veggies = ["Beans", "Broc", "Ban"]
for veggie in veggies:
    if "Broc" in veggie:
        continue
print(veggie)

