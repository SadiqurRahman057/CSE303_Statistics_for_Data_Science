# Operator
print(2**52)
print(2**56//10)
print (2**53)

# checking the statement is true or false:
print(f"The statement is {2**2<=2**56//10<2**53}")        